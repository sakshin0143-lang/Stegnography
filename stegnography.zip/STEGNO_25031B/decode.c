#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

/* Open the stego image file */
Status open_decode_files(DecodeInfo *decInfo)
{
    /* Open stego image in read-binary mode */
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "rb");
    if (decInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        return e_failure;
    }
    return e_success;
}

/* Read and validate decode command-line arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    /* Check whether source image is a .bmp file */
    char *ptr = strstr(argv[2], ".bmp");
    if (ptr == NULL || strcmp(ptr, ".bmp") != 0)
    {
        printf("ERROR: Source image must be a .bmp file\n");
        return e_failure;
    }

    decInfo->src_image_fname = argv[2];

    /* Output file name (without extension) */
    if (argv[3] != NULL)
    {
        char temp[100];
        strcpy(temp, argv[3]);   // strtok modifies string, so copy to temp

        char *token = strtok(temp, ".");
        if (token != NULL)
        {
            strcpy(decInfo->out_fname, token);
        }
    }
    else
    {
        /* Default output file name */
        strcpy(decInfo->out_fname, "output");
    }

    return e_success;
}

/* Decode one character from LSB of 8 image bytes */
Status decode_byte_from_lsb(char *data, FILE *fptr_src_image)
{
    char image_byte;
    *data = 0;

    /* Extract one bit from each byte */
    for (int i = 0; i < 8; i++)
    {
        fread(&image_byte, 1, 1, fptr_src_image);
        *data |= ((image_byte & 1) << i);
    }
    return e_success;
}

/* Decode 32-bit integer size from LSB */
Status decode_size_from_lsb(int *size, FILE *fptr_src_image)
{
    char image_byte;
    *size = 0;

    /* Extract 32 bits */
    for (int i = 0; i < 32; i++)
    {
        fread(&image_byte, 1, 1, fptr_src_image);
        *size |= ((image_byte & 1) << i);
    }
    return e_success;
}

/* Decode and verify magic string */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo)
{
    /* Skip 54-byte BMP header */
    fseek(decInfo->fptr_src_image, 54, SEEK_SET);

    int len = strlen(magic_string);
    char decoded[len + 1];

    /* Decode magic string characters */
    for (int i = 0; i < len; i++)
    {
        decode_byte_from_lsb(&decoded[i], decInfo->fptr_src_image);
    }
    decoded[len] = '\0';

    /* Compare decoded magic string */
    if (strcmp(decoded, magic_string) != 0)
    {
        printf("ERROR: Magic string mismatch\n");
        return e_failure;
    }

    return e_success;
}

/* Decode secret file extension size */
Status decode_secret_file_extn_size(int *extn_size, DecodeInfo *decInfo)
{
    decode_size_from_lsb(extn_size, decInfo->fptr_src_image);
    return e_success;
}

/* Decode secret file extension */
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo)
{
    int extn_size;

    /* Get extension size */
    decode_secret_file_extn_size(&extn_size, decInfo);

    /* Decode extension characters */
    for (int i = 0; i < extn_size; i++)
    {
        decode_byte_from_lsb(&file_extn[i], decInfo->fptr_src_image);
    }
    file_extn[extn_size] = '\0';

    return e_success;
}

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    int size;

    /* Decode size of secret file */
    decode_size_from_lsb(&size, decInfo->fptr_src_image);
    decInfo->size_secret_file = size;

    return e_success;
}

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    /* Open output file in write-binary mode */
    decInfo->fptr_out = fopen(decInfo->out_fname, "wb");
    if (decInfo->fptr_out == NULL)
    {
        perror("fopen");
        return e_failure;
    }

    char data;

    /* Decode secret file content byte by byte */
    for (int i = 0; i < decInfo->size_secret_file; i++)
    {
        decode_byte_from_lsb(&data, decInfo->fptr_src_image);
        fwrite(&data, 1, 1, decInfo->fptr_out);
    }

    fclose(decInfo->fptr_out);
    return e_success;
}

/* Perform complete decoding process */
Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_failure)
        return e_failure;

    printf("Opening the files completed\n");

    if (decode_magic_string(MAGIC_STRING, decInfo) == e_failure)
        return e_failure;

    printf("Decoding the magic string is succesfull\n");

    if (decode_secret_file_extn(decInfo->extn_secret_file, decInfo) == e_failure)
        return e_failure;

    printf("Decoding the secret file extension is succesfull\n");

    /* Append extension to output file name */
    strcat(decInfo->out_fname, decInfo->extn_secret_file);

    if (decode_secret_file_size(decInfo) == e_failure)
        return e_failure;

    printf("Decoding the secret file size is succesfull\n");

    if (decode_secret_file_data(decInfo) == e_failure)
        return e_failure;

    printf("Decoding the secret file data is succesfull\n");

    fclose(decInfo->fptr_src_image);
    return e_success;
}
