/*
Name        : Sakshi N

Project     : Image Steganography using LSB Technique

Sample Input:
Encoding  : ./stego -e source.bmp secret.txt output.bmp
Decoding  : ./stego -d output.bmp decoded.txt

Sample Output:
Encoding completed successfully
Decoding completed successfully
Secret data extracted from image
Description:
This program hides a secret file inside a BMP image using the Least Significant Bit method.
It supports encoding and decoding of text/source files while preserving image quality.
*/
#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    if(argc==1)
    {
        printf("Enter -e for encoding or -d for decoding\n");
        return e_failure;
    }
    if ((strcmp(argv[1], "-e") == 0 && argc >= 3) ||
        (strcmp(argv[1], "-d") == 0 && argc >= 2))
    {
        OperationType op = check_operation_type(argv[1]);

        if(op == e_encode)
        {
            EncodeInfo encInfo;
            if(read_and_validate_encode_args(argv, &encInfo) == e_success)
            {
                if(do_encoding(&encInfo) != e_success)
                {
                    printf("error to do encoding\n");
                }
            }
            else
            {
                printf("Arguments validation failed due to format mismatch\n");
            }
        }
        else if(op == e_decode)
        {
            DecodeInfo decInfo;
            if(read_and_validate_decode_args(argv, &decInfo) == e_success)
            {
                if(do_decoding(&decInfo) != e_success)
                {
                    printf("error to do decoding\n");
                }
            }
            else
            {
                printf("Arguments validation failed due to format mismatch\n");
            }
        }
    }
    else
    {
        printf("Please enter a valid number of command line arguments\n");
    }

    return 0;
}
OperationType check_operation_type(char *symbol)
{
    if(strcmp("-e", symbol) == 0)
        return e_encode;
    else if(strcmp("-d", symbol) == 0)
        return e_decode;
    else
        return e_unsupported;
}