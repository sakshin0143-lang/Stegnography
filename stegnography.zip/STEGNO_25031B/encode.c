#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"

/* Get image size (width * height * 3 bytes) */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;

    /* Width and height are stored at offset 18 in BMP */
    fseek(fptr_image, 18, SEEK_SET);
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    return width * height * 3;   // RGB image
}

/* Get size of secret file */
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    int size = ftell(fptr);
    rewind(fptr);

    printf("Secret file size: %d bytes\n", size);
    return (uint)size;
}

/* Read and validate command-line arguments */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    char *ptr;

    /* Validate source image (.bmp) */
    ptr = strrchr(argv[2], '.');
    if (ptr == NULL || strcmp(ptr, ".bmp") != 0)
        return e_failure;
    encInfo->src_image_fname = argv[2];

    /* Validate secret file extensions */
    ptr = strrchr(argv[3], '.');
    if (ptr == NULL ||
        (strcmp(ptr, ".txt") != 0 &&
         strcmp(ptr, ".c")   != 0 &&
         strcmp(ptr, ".h")   != 0 &&
         strcmp(ptr, ".sh")  != 0))
        return e_failure;
    encInfo->secret_fname = argv[3];

    /* Destination image is optional */
    if (argv[4] != NULL)
    {
        ptr = strrchr(argv[4], '.');
        if (ptr == NULL || strcmp(ptr, ".bmp") != 0)
            return e_failure;
        encInfo->dest_image_fname = argv[4];
    }
    else
    {
        encInfo->dest_image_fname = "destination.bmp";
    }

    return e_success;
}

/* Open all required files */
Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    if (encInfo->fptr_src_image == NULL)
        return e_failure;

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
        return e_failure;

    encInfo->fptr_dest_image = fopen(encInfo->dest_image_fname, "wb");
    if (encInfo->fptr_dest_image == NULL)
        return e_failure;

    return e_success;
}

/* Check if image has enough capacity */
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    printf("Total Image Capacity = %d\n", encInfo->image_capacity);

    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    if (encInfo->image_capacity >
        ((16 + 32 + 32 + 32) + (encInfo->size_secret_file * 8)))
        return e_success;
    else
        return e_failure;
}

/* Copy first 54 bytes of BMP header */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char buffer[54];

    rewind(fptr_src_image);
    fread(buffer, 1, 54, fptr_src_image);
    fwrite(buffer, 1, 54, fptr_dest_image);

    return e_success;
}

/* Encode one character into 8 image bytes */
Status encode_byte_to_lsb(char data, char *imageBuffer)
{
    for (int i = 0; i < 8; i++)
    {
        imageBuffer[i] &= ~1;                 // Clear LSB
        imageBuffer[i] |= ((data >> i) & 1);  // Set bit
    }
    return e_success;
}

/* Encode integer size into 32 image bytes */
Status encode_size_to_lsb(int size, char *imageBuffer)
{
    for (int i = 0; i < 32; i++)
    {
        imageBuffer[i] &= ~1;
        imageBuffer[i] |= ((size >> i) & 1);
    }
    return e_success;
}

/* Encode magic string */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char buffer[8];

    for (int i = 0; magic_string[i] != '\0'; i++)
    {
        fread(buffer, 1, 8, encInfo->fptr_src_image);
        encode_byte_to_lsb(magic_string[i], buffer);
        fwrite(buffer, 1, 8, encInfo->fptr_dest_image);
    }
    return e_success;
}

/* Encode secret file extension size */
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    char buffer[32];

    fread(buffer, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(size, buffer);
    fwrite(buffer, 1, 32, encInfo->fptr_dest_image);

    return e_success;
}

/* Encode secret file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char buffer[8];

    for (int i = 0; file_extn[i] != '\0'; i++)
    {
        fread(buffer, 1, 8, encInfo->fptr_src_image);
        encode_byte_to_lsb(file_extn[i], buffer);
        fwrite(buffer, 1, 8, encInfo->fptr_dest_image);
    }
    return e_success;
}

/* Encode secret file size */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char buffer[32];

    fread(buffer, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(file_size, buffer);
    fwrite(buffer, 1, 32, encInfo->fptr_dest_image);

    return e_success;
}

/* Encode secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char buffer[8];
    char ch;

    rewind(encInfo->fptr_secret);
    while (fread(&ch, 1, 1, encInfo->fptr_secret) == 1)
    {
        fread(buffer, 1, 8, encInfo->fptr_src_image);
        encode_byte_to_lsb(ch, buffer);
        fwrite(buffer, 1, 8, encInfo->fptr_dest_image);
    }
    return e_success;
}

/* Copy remaining image data */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;

    while (fread(&ch, 1, 1, fptr_src) == 1)
        fwrite(&ch, 1, 1, fptr_dest);

    return e_success;
}

/* Main encoding function */
Status do_encoding(EncodeInfo *encInfo)
{
    if (open_files(encInfo) == e_failure)
        return e_failure;

    printf("Opening the files completed\n");

    if (check_capacity(encInfo) == e_failure)
        return e_failure;

    printf("Image capacity is greater than the secret file\n");

    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_dest_image) == e_failure)
        return e_failure;

    printf("Copying the bmp header is succesfull\n");

    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure)
        return e_failure;

    printf("Encoding the magic string is succesfull\n");

    char *ptr = strrchr(encInfo->secret_fname, '.');
    if (ptr != NULL)
        strcpy(encInfo->extn_secret_file, ptr);

    int size = strlen(encInfo->extn_secret_file);

    if (encode_secret_file_extn_size(size, encInfo) == e_failure)
        return e_failure;

    printf("Encoding the secret file extension size is succesfull\n");

    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_failure)
        return e_failure;

    printf("Encoding the secret file extn is succesfull\n");

    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)
        return e_failure;

    printf("Encoding the secret file size is succesfull\n");

    if (encode_secret_file_data(encInfo) == e_failure)
        return e_failure;

    printf("Encoding the secret file data is succesfull\n");

    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_dest_image) == e_failure)
        return e_failure;

    printf("Copying the remaining data is succesfull\n");

    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_dest_image);

    return e_success;
}
