#include<stdio.h>
void secret_mesage(void)
{
    printf("Ee sala cup namdu\n");
}
