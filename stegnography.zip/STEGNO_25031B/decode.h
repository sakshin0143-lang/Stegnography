#define DECODE_H

#include <stdio.h>
#include "types.h"

/*
 * Structure to store information required for
 * decoding secret file from stego image
 */
typedef struct _DecodeInfo
{
    /* Stego Image Info (input to decoding) */
    char *src_image_fname;
    FILE *fptr_src_image;

    /* Secret File Info */
    char extn_secret_file[10];
    long size_secret_file;

    /* Output File Info */
    char out_fname[100];
    FILE *fptr_out;

} DecodeInfo;

/* Read and validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Open required files */
Status open_decode_files(DecodeInfo *decInfo);

/* Decode magic string */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo);

/* Decode secret file extension size */
Status decode_secret_file_extn_size(int *extn_size, DecodeInfo *decInfo);

/* Decode secret file extension */
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo);

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

/* Decode a byte from LSB */
Status decode_byte_from_lsb(char *data, FILE *fptr_src_image);

/* Decode size from LSB */
Status decode_size_from_lsb(int *size, FILE *fptr_src_image);